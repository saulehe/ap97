namespace A7
{
    public enum Degree
    {
    }
}