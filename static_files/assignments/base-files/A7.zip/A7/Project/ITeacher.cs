namespace A7
{
    public interface ITeacher
    {

    }
}