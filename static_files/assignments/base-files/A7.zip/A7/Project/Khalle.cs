namespace A7
{
    public class Khalle
    {
    }
}