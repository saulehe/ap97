using System;
using System.Collections.Generic;

namespace A7
{
    public static class PoliceStation
    {
        public static bool BackgroundCheck(ICitizen citizen)
        {
            throw new NotImplementedException();
        }
    }
}