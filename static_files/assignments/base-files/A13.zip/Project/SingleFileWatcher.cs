﻿using System;
using System.IO;

namespace EventDelegateThread
{

    public class SingleFileWatcher: IDisposable
    {
        private FileSystemWatcher Watcher;
       
    }
}