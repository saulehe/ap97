﻿using System;
using System.IO;

namespace A13
{

    public class SingleFileWatcher: IDisposable
    {
        private FileSystemWatcher Watcher;
		
    }
}