﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using System;

namespace EventDelegateThread
{
    public static class ActionTools
    {
        public static long CallSequential(params Action[] actions)
        {
            Stopwatch sw = Stopwatch.StartNew();
            foreach (var action in actions)
                action();
            return sw.ElapsedMilliseconds;
        }

        public static long CallParallel(params Action[] actions)
        {
            Stopwatch sw = Stopwatch.StartNew();
            //Parallel.ForEach(actions, a => a());
            List<Task> myTasks = new List<Task>();
            foreach (var action in actions)
                myTasks.Add(Task.Run(action));

            Task.WaitAll(myTasks.ToArray());
            return sw.ElapsedMilliseconds;
        }

        public static long CallParallelThreadSafe(int count, params Action[] actions)
        {
            object syncObj = new object();
            Stopwatch sw = Stopwatch.StartNew();
            //Parallel.ForEach(actions, a => a());
            List<Task> myTasks = new List<Task>();
            foreach (var action in actions)
                myTasks.Add(Task.Run(() =>
                {
                    for (int i = 0; i < count; i++)
                    {
                        lock (syncObj)
                        {
                            action();
                        }
                    }
                }));

            Task.WaitAll(myTasks.ToArray());
            return sw.ElapsedMilliseconds;
        }


        public static async Task<long> CallSequentialAsync(params Action[] actions)
        {
            Stopwatch sw = Stopwatch.StartNew();
            foreach (var a in actions)
                await Task.Run(a);
            return sw.ElapsedMilliseconds;
        }

        public static async Task<long> CallParallelAsync(params Action[] actions)
        {
            Stopwatch sw = Stopwatch.StartNew();
            //Parallel.ForEach(actions, a => a());
            List<Task> myTasks = new List<Task>();
            foreach (var action in actions)
                myTasks.Add(Task.Run(action));

            await Task.WhenAll(myTasks);

            return sw.ElapsedMilliseconds;
        }

        public static async Task<long> CallParallelThreadSafeAsync(int count, params Action[] actions)
        {
            object syncObj = new object();
            Stopwatch sw = Stopwatch.StartNew();
            //Parallel.ForEach(actions, a => a());
            List<Task> myTasks = new List<Task>();
            foreach (var action in actions)
                myTasks.Add(Task.Run(() =>
                {
                    for (int i = 0; i < count; i++)
                    {
                        lock (syncObj)
                        {
                            action();
                        }
                    }
                }));

            await Task.WhenAll(myTasks.ToArray());

            return sw.ElapsedMilliseconds;
        }
    }
}