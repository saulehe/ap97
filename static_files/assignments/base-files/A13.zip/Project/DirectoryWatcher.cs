﻿using System;
using System.IO;

namespace EventDelegateThread
{
    public enum ObserverType { Create, Delete }

    public class DirectoryWatcher: IDisposable
    {
       
    }
}