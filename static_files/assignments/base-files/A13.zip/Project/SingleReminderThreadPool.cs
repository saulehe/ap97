﻿using System;
using System.Threading;

namespace A13
{   
    public class SingleReminderThreadPool : ISingleReminder
    {
        
    }
}