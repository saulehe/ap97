﻿using System;
using System.Threading;

namespace EventDelegateThread
{   
    public class SingleReminderThreadPool : ISingleReminder
    {
        
    }
}