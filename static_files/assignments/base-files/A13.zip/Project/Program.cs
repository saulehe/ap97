﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using System;

namespace EventDelegateThread
{
    public class Program
    {
        public static void Main(string[] args)
        {
        }
    }
}
