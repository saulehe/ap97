﻿using System;
using System.Threading;

namespace EventDelegateThread
{
    public class SingleReminderThread : ISingleReminder
    {
        Thread ReiminderThread = null;
       
    }
}