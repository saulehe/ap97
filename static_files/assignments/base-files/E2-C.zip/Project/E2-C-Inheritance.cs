﻿namespace E2
{
    public abstract class Person
    {
    }

    public class Student : Person
    {
    }

    public class Employee : Person
    {
    }

    public class Teacher: Employee
    {
    }
}