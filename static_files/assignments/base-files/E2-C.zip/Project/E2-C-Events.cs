﻿using System;
using System.Collections.Generic;
using System.Timers;

namespace E2
{
    public class DuplicateNumberDetector
    {
        public void AddNumber(int n)
        {
            throw new NotImplementedException();
        }

        public event Action<int> DuplicateNumberAdded;
    }
}