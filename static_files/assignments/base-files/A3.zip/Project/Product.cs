using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A3
{
    public class Product
    {
        public string Name;
        public float Price;

        public Product(string name, float price)
        {
        }
    }
}